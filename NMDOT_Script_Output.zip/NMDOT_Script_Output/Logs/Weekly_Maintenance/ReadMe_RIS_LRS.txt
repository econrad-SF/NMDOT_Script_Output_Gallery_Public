RHLockRoot push + RIS_LRS Weekly Maintenance

Roadway Inventory Program will have versions closed/cleaned up by 4 PM on Friday so maintenance scripts can run.

Maintenance Items on the docket:
1. Push RHLockRoot to DEFAULT and delete Sandbox version
2. Manually delete any remaining R&H locks (no API access)
3. Update DisplayIDs and identify invalid RouteIDs
4. Generate Routes
5. Generate Events
6. Update Intersection Points (not run by script, memory error will occur)
7. Compress database
8. Rebuild database indices 
9. Analyze Datasets
10. Recreate RHLockRoot and Sandbox versions 
11. Transfer RIS_LRS to NMDOT_PUB (excludes Redline, retired routes & events, and static reference datasets such as County Boundaries)
12. Update NMDOT_Maintained_Routes feature class in NMDOT_PUB
13. Update SignDetail relationship class in NMDOT_PUB for EGIS
