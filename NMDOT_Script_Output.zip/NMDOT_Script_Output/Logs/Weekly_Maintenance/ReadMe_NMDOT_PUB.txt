Maintenance Items on the docket:
1. Push LockRoot versions to DEFAULT
2. Compress database
3. Rebuild database indices 
4. Analyze Datasets
5. Recreate LockRoot versions 
6. Transfer RIS_LRS to NMDOT_PUB (excludes retired routes & events)
7. Update NMDOT_Maintained_Routes feature class in NMDOT_PUB
8. Update SignDetail relationship class in NMDOT_PUB for EGIS
